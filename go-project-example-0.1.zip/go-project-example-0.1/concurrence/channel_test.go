package concurrence

import "testing"

func TestCalSquare(t *testing.T) {
	CalSquare()
}
