package test

func JudgePassLine(score int16) bool {
	if score >= 60 {
		return true
	}
	return false
}
