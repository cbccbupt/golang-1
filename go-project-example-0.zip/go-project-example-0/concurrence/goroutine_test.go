package concurrence

import "testing"

func TestManyGo(t *testing.T) {
		HelloGoRoutine()
}
