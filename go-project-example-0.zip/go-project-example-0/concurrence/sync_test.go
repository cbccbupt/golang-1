package concurrence

import "testing"

func TestAddLock(t *testing.T) {
	Add()
}


func TestManyGoWait(t *testing.T){
	ManyGoWait()
}