package test


func HelloTom() string {
	return "Tom"
}
